<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-16">
  <title>සැඟවුණු භාණ්ඩය සෙවීම </title>
  
  
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
 <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
  
  <style>
  
  
  #object{
  
  z-index:-3;
  position:absolute;
  top:-1px;
  left:1000px;
  height:200px;
  width:200px;
 
 
  
  
  }
  
  #panel{
  position:absolute;
  width:700px;
  height:130px;
  z-index:60;
	background-color:navy;
	color:#FFFFFF;
	padding:50px;
	left:100px;
	display:none;
	height:500px;
}
  
  
  

 table
{
position:absolute;
left:100px;
top:80px;
height:500px;
width:800px;
border: 4px solid black;
text-align:center;
overflow:scroll;
background-color:#FFCC00;
 background-image:url('img/cover.jpg');


}


#curtain{

color:#FFFFFF;
position:absolute;
left:100px;
top:80px;
height:500px;
width:800px;
background-color:#FF8533;
background-image:url('img/curtain.jpg');
}


  
  td:hover{
  
  background-color:navy;
 
  }
  
   body{
  
  
  background-image:url('img/home.jpg');
  
	background-color:#cccccc;
	
  
  }
  
  
  
  #info{
  
	position:absolute;
	left:100px;
	top:10px;
	height:50px;
	background-color:#FFCC66;
	border:solid 3px yellow;
	
	
  
  }
  
  
  </style>
  
  <script>
  
  
  //random number generation;
  x=Math.floor((Math.random()*10)+1);
  y=Math.floor((Math.random()*10)+1);
  
  //str is the position of the hidden object;
  str=x+"&"+y;
  
  //click count
  clicks=1;
  
  //win or loose;
  status=false;
  
	
	$(document).ready(function(){
	
	
	$("#object").animate({
      top:'300px'
  
    });
	
	$("#object").animate({
      top:'280px'
  
    },100);
	
	$("#object").animate({
      left:'200px',height:'60px',width:'60px'
     
    },1600,function(){
	
	$("#curtain").animate({left:'-1000px'},1600);
	
	
	
	
	});
	
	
	
		
	
	
	 $("td").click(function(){
	 
	 if(  clicks>3 ){
	 
	 alert("your attemps over");
	 
	 }else{
	 
		clicks++;
		
		g=$(this).attr("id");
		
		//alert("random "+str);
		
		if(str==g){
		
		$(this).css("background-image","url('img/happy.png')");
		$("#panel").slideDown(1600).html("<h2> සුබ පැතුම් ! .. ඔබ භාණ්ඩය සොයා ගත්තා  ..  අවසන් ජයග්‍රාහකයා දැනුම් දෙනතුරු ඉවසන්න   </h2>");
		status=true;
		}else{
		
		
		$(this).css( "background-image","url('img/sad_1.png')" );
		
		if(clicks==4){
		
		$("#panel").slideDown(1200).html("<h1> කනගාටුයි ඔබේ සැඟවුණු භාණ්ඩය සොයා ගැනීමේ වාසනාව සැඟවී ගියා ... ඔබට ස්තුතියි !   </h1>");
		
		}
		
		
		}
	 
		//..
		}
	 
	 
	 
	 });
	
	
	
	
	
	});
	
  
  
  </script>
  

  
</head>
<body>


<div id="table"  >

<table border="1"   >

<?php


$y=1;

while($y<=10){
	
echo "<tr>


	
 <td id='1&".$y."'> &nbsp; </td>
 <td id='2&".$y."'> &nbsp;</td>
 <td id='3&".$y."'> &nbsp;</td>
 <td id='4&".$y."'> &nbsp;</td>
 <td id='5&".$y."'> &nbsp;</td>
 <td id='6&".$y."'> &nbsp;</td>
 <td id='7&".$y."'> &nbsp;</td>
 <td id='8&".$y."'> &nbsp;</td>
 <td id='9&".$y."'> &nbsp;</td>
 <td id='10&".$y."'> &nbsp;</td>
 
 

 
 </tr>";	
	
	
 $y++;   } 
 
 
 ?>


</table> 

  </div>
  
  
  <div id="panel"></div>
  <div id="info" align="center" ><b><h3>ඔබට භාණ්ඩය සොයාගැනීමට අවස්ථා තුනක් ලැබෙනවා . භාණ්ඩය සොයාගැනීම සඳහා පහත grid එකේ cell මත click කරන්න . </h3></b> </div>
  <img src="img/box.png" id="object"/>
  <div id="curtain" align="center" ><h1>මදක් ඉවසන්න<h1> </div>
  
</body>
</html>